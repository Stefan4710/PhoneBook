﻿namespace PhoneBook
{


    partial class AppData
    {
        partial class PhoneBookDataTable
        {
        }
    }
}
namespace PhoneBook {
    
    
    public partial class AppData {
    }
}
namespace PhoneBook {
    
    
    public partial class AppData {
    }
}
